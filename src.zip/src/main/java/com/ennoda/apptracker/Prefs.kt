package com.ennoda.apptracker

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("tracker", Context.MODE_PRIVATE)

    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun getLimit(c: Context, pkg: String): Int = sp(c).getInt("limit_$pkg", 120)

    fun setLimit(c: Context, pkg: String, minutes: Int) {
        sp(c).edit().putInt("limit_$pkg", minutes).apply()
        // limit changed -> allow a fresh alert today
        sp(c).edit().remove("notified_$pkg").apply()
    }

    fun getDailyGoal(c: Context): Int = sp(c).getInt("daily_goal", 240)

    fun setDailyGoal(c: Context, minutes: Int) {
        sp(c).edit().putInt("daily_goal", minutes).apply()
    }

    fun wasNotifiedToday(c: Context, pkg: String): Boolean =
        sp(c).getString("notified_$pkg", "") == today()

    fun markNotified(c: Context, pkg: String) {
        sp(c).edit().putString("notified_$pkg", today()).apply()
    }
}
