package com.ennoda.apptracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.util.concurrent.Executors

class TrackerService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    private val tick = object : Runnable {
        override fun run() {
            worker.execute { checkUsage() }
            handler.postDelayed(this, 30_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Tracking status", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Limit alerts", NotificationManager.IMPORTANCE_HIGH)
        )
        val n = statusNotification("Tracking app usage…")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_STATUS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_STATUS, n)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        worker.shutdown()
        super.onDestroy()
    }

    private fun statusNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CH_STATUS)
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setContentTitle("Ennoda App Time Tracker")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun checkUsage() {
        if (!UsageRepo.hasPermission(this)) return
        val usage = UsageRepo.todayUsage(this)
        val total = usage.sumOf { it.millis }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val top = usage.firstOrNull()
        val text = "Today: ${fmt(total)}" + if (top != null) "  •  Top: ${top.label}" else ""
        nm.notify(ID_STATUS, statusNotification(text))

        for (u in usage) {
            val limitMs = Prefs.getLimit(this, u.pkg) * 60_000L
            if (u.millis >= limitMs && !Prefs.wasNotifiedToday(this, u.pkg)) {
                Prefs.markNotified(this, u.pkg)
                val alert = Notification.Builder(this, CH_ALERT)
                    .setSmallIcon(android.R.drawable.ic_dialog_alert)
                    .setContentTitle("${u.label} daily limit reached")
                    .setContentText("You used ${u.label} for ${fmt(u.millis)} today. Take a break!")
                    .setAutoCancel(true)
                    .build()
                nm.notify(u.pkg.hashCode(), alert)
            }
        }
    }

    companion object {
        const val CH_STATUS = "status"
        const val CH_ALERT = "alerts"
        const val ID_STATUS = 1

        fun fmt(ms: Long): String {
            val mins = ms / 60_000L
            val h = mins / 60
            val m = mins % 60
            return if (h == 0L) "${m}m" else "${h}h ${m}m"
        }

        fun start(c: Context) {
            val i = Intent(c, TrackerService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
    }
}
