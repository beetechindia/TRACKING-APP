package com.ennoda.apptracker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val refresher = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 5_000L)
        }
    }

    private lateinit var root: LinearLayout

    private val BG = Color.parseColor("#0F172A")
    private val CARD = Color.parseColor("#1E293B")
    private val TEXT = Color.parseColor("#F1F5F9")
    private val MUTED = Color.parseColor("#94A3B8")
    private val GREEN = Color.parseColor("#34D399")
    private val INDIGO = Color.parseColor("#6366F1")
    private val RED = Color.parseColor("#F43F5E")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(24))
        scroll.addView(
            root,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        if (UsageRepo.hasPermission(this)) TrackerService.start(this)
        handler.post(refresher)
    }

    override fun onPause() {
        handler.removeCallbacks(refresher)
        super.onPause()
    }

    private fun refresh() {
        Thread {
            val data = UsageRepo.todayUsage(this)
            runOnUiThread { render(data) }
        }.start()
    }

    private fun render(usage: List<AppUsage>) {
        root.removeAllViews()
        root.addView(label("📱 Ennoda App Time Tracker", 20f, TEXT, bold = true))
        root.addView(space(12))

        if (!UsageRepo.hasPermission(this)) {
            val c = card()
            c.addView(label("Usage Access permission needed", 16f, TEXT, bold = true))
            c.addView(
                label(
                    "Automatic tracking-க்கு 'Usage access' ON பண்ணனும். Next screen-ல் " +
                        "Ennoda App Time Tracker-ஐ தேர்ந்தெடுத்து 'Permit usage access' ON பண்ணு.",
                    13f, MUTED
                )
            )
            c.addView(space(8))
            c.addView(button("Open Usage Access Settings", INDIGO) {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            })
            root.addView(c)
            return
        }

        val total = usage.sumOf { it.millis }
        val goalMin = Prefs.getDailyGoal(this)
        val goalMs = goalMin * 60_000L

        // Summary card
        val summary = card()
        summary.addView(label("TODAY'S TOTAL SCREEN TIME", 11f, MUTED, bold = true))
        summary.addView(label(TrackerService.fmt(total), 34f, TEXT, bold = true))
        val top = usage.firstOrNull()
        summary.addView(
            label(
                if (top != null) "Most used: ${top.label} (${TrackerService.fmt(top.millis)})"
                else "No usage recorded yet today",
                13f, GREEN
            )
        )
        summary.addView(space(8))
        val pct = if (goalMs > 0) minOf(100L, total * 100 / goalMs).toInt() else 0
        summary.addView(label("Daily goal: ${TrackerService.fmt(goalMs)}  •  $pct%  (tap to change)", 12f, MUTED).also {
            it.setOnClickListener { askMinutes("Daily goal (minutes)", goalMin) { v -> Prefs.setDailyGoal(this, v); refresh() } }
        })
        summary.addView(progress(pct, if (total > goalMs) RED else INDIGO))
        root.addView(summary)

        // App list
        root.addView(label("App-wise usage", 15f, TEXT, bold = true))
        root.addView(space(6))
        if (usage.isEmpty()) {
            root.addView(label("Use your phone normally — apps will appear here automatically.", 13f, MUTED))
        }
        for (u in usage) {
            val limitMin = Prefs.getLimit(this, u.pkg)
            val limitMs = limitMin * 60_000L
            val over = u.millis >= limitMs
            val p = if (limitMs > 0) minOf(100L, u.millis * 100 / limitMs).toInt() else 100

            val row = card()
            val head = LinearLayout(this)
            head.orientation = LinearLayout.HORIZONTAL
            val name = label(u.label, 15f, TEXT, bold = true)
            head.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            head.addView(label(TrackerService.fmt(u.millis), 15f, if (over) RED else GREEN, bold = true))
            row.addView(head)
            row.addView(
                label(
                    "Limit ${TrackerService.fmt(limitMs)}" + if (over) "  •  ⚠ limit reached" else "  (tap to change)",
                    12f, if (over) RED else MUTED
                )
            )
            row.addView(progress(p, if (over) RED else GREEN))
            row.setOnClickListener {
                askMinutes("${u.label} daily limit (minutes)", limitMin) { v ->
                    Prefs.setLimit(this, u.pkg, v)
                    refresh()
                }
            }
            root.addView(row)
        }

        // Reliability helpers
        root.addView(space(8))
        val help = card()
        help.addView(label("Keep tracking reliable", 14f, TEXT, bold = true))
        help.addView(
            label(
                "Redmi/MIUI phones background apps-ஐ kill பண்ணலாம். கீழே உள்ள button மூலம் " +
                    "battery restriction-ஐ off பண்ணு. மேலும் Settings → Apps → Manage apps → " +
                    "Ennoda App Time Tracker → Autostart ON, Battery saver → No restrictions.",
                12f, MUTED
            )
        )
        help.addView(space(6))
        help.addView(button("Disable battery optimization", INDIGO) { requestIgnoreBattery() })
        help.addView(space(6))
        help.addView(button("Open app settings (Autostart)", Color.parseColor("#334155")) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })
        root.addView(help)
    }

    private fun requestIgnoreBattery() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun askMinutes(title: String, current: Int, onOk: (Int) -> Unit) {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_NUMBER
        input.setText(current.toString())
        input.setSelection(input.text.length)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val v = input.text.toString().toIntOrNull()
                if (v != null && v > 0) onOk(v)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- small UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun space(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(1, dp(h))
        return v
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(CARD)
        bg.cornerRadius = dp(16).toFloat()
        c.background = bg
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(10)
        c.layoutParams = lp
        return c
    }

    private fun progress(percent: Int, color: Int): ProgressBar {
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = 100
        pb.progress = percent
        pb.progressTintList = ColorStateList.valueOf(color)
        pb.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#334155"))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8))
        lp.topMargin = dp(8)
        pb.layoutParams = lp
        return pb
    }

    private fun button(text: String, color: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.setColor(color)
        bg.cornerRadius = dp(12).toFloat()
        b.background = bg
        b.gravity = Gravity.CENTER
        b.setOnClickListener { onClick() }
        return b
    }
}
