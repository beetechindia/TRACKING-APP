package com.ennoda.apptracker

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import java.util.Calendar

data class AppUsage(val pkg: String, val label: String, val millis: Long)

object UsageRepo {

    fun hasPermission(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun dayStart(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    /** Foreground time per app since today's midnight, highest first. */
    fun todayUsage(c: Context): List<AppUsage> {
        if (!hasPermission(c)) return emptyList()

        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val start = dayStart()
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(start, now)
        val e = UsageEvents.Event()

        val openSince = HashMap<String, Long>()   // pkg -> time it came to foreground
        val totals = HashMap<String, Long>()
        val seenFirst = HashSet<String>()

        // Event type numbers: 1 = MOVE_TO_FOREGROUND / ACTIVITY_RESUMED,
        // 2 = MOVE_TO_BACKGROUND / ACTIVITY_PAUSED, 16 = SCREEN_NON_INTERACTIVE (screen off)
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            val t = e.timeStamp
            when (e.eventType) {
                1 -> {
                    seenFirst.add(pkg)
                    val prev = openSince[pkg]
                    if (prev != null) totals[pkg] = (totals[pkg] ?: 0L) + (t - prev)
                    openSince[pkg] = t
                }
                2 -> {
                    val prev = openSince.remove(pkg)
                    if (prev != null) {
                        totals[pkg] = (totals[pkg] ?: 0L) + (t - prev)
                    } else if (!seenFirst.contains(pkg)) {
                        // app was already open before midnight
                        totals[pkg] = (totals[pkg] ?: 0L) + (t - start)
                    }
                    seenFirst.add(pkg)
                }
                16 -> {
                    for ((p, s) in openSince) totals[p] = (totals[p] ?: 0L) + (t - s)
                    openSince.clear()
                }
            }
        }
        // apps still open right now
        for ((p, s) in openSince) totals[p] = (totals[p] ?: 0L) + (now - s)

        val pm = c.packageManager
        val homePkg = pm.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName

        val result = ArrayList<AppUsage>()
        for ((pkg, ms) in totals) {
            if (ms < 1000L) continue
            if (pkg == homePkg || pkg == c.packageName) continue
            if (pm.getLaunchIntentForPackage(pkg) == null) continue
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (ex: Exception) {
                pkg
            }
            result.add(AppUsage(pkg, label, ms))
        }
        result.sortByDescending { it.millis }
        return result
    }
}
