package com.ennoda.apptracker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (UsageRepo.hasPermission(context)) {
            try {
                TrackerService.start(context)
            } catch (e: Exception) {
                // Some phones block service start at boot; the app will resume tracking when opened.
            }
        }
    }
}
